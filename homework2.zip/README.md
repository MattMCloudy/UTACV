Computer Vision Lab 2
Matthew McLeod
July 10, 2018
1000895526

this program accepts two inputs, an image, and a model file

the model file is simply a line separated text file with expected diameters for each coin

one has been provided to work with the provided images

cmake . && make && ./lab2 CoinImages/IMG_0001.JPG model.txt